
function  Help () {
  echo -e "${YELLOW}-l: ${NC} List available Acces Points."
  echo -e "${YELLOW}-lsort: ${NC} List available Acces Points ordered by signal intensity."
  echo -e "${YELLOW}-d: ${NC} Diactivate NetworkManager service."
  echo -e "${YELLOW}-c: ${NC} Manually configur Acces point's acces."
  echo -e "${YELLOW}-v: ${NC} Current Version."
}

function version() {
  echo "WiScript version 0.1.69"
}
